﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RenataDolgozat0513
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Konyvesbolt> konyvek=new List<Konyvesbolt>();


        private void Form1_Load(object sender, EventArgs e)
        {
            string[] sorok = File.ReadAllLines("konyvesbolt.txt");
            foreach(string s in sorok)
            {
                string[] adatok = s.Split(';');
                Konyvesbolt konyv = new Konyvesbolt(adatok[0], adatok[1], adatok[2], adatok[3], adatok[4]);
                konyvek.Add(konyv);
            }

            foreach(var k in konyvek)
            {
                dataGridView1.Rows.Add(k.kategoria, k.konyv_cime, k.egysegar, k.raktar_db,k.eladott_db);
                if (!comboBox1.Items.Contains(k.kategoria))
                {
                    comboBox1.Items.Add(k.kategoria);
                }
            }
            int osszbevetel = 0;
            foreach(var k in konyvek)
            {
                int bevetel = k.egysegar * k.eladott_db;
                dataGridView2.Rows.Add(k.konyv_cime, bevetel);
                osszbevetel += bevetel;
            }
            label2.Text = ($"Az összes bevétel:{osszbevetel} Ft.");

        }
        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var k in konyvek)
            {
                if (k.kategoria == comboBox1.SelectedItem.ToString())
                {
                    listBox1.Items.Add(k.konyv_cime);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                listBox1.Items.Clear();

            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

