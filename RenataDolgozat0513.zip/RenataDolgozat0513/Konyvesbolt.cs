﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RenataDolgozat0513
{
    internal class Konyvesbolt
    {
        public string kategoria;
        public string konyv_cime;
        public int egysegar;
        public int raktar_db;
        public int eladott_db;

        public Konyvesbolt(string kategoria, string konyv_cime, string egysegar, string raktar_db, string eladott_db)
        {
            this.kategoria = kategoria;
            this.konyv_cime = konyv_cime;
            this.egysegar = int.Parse(egysegar);
            this.raktar_db = int.Parse(raktar_db);
            this.eladott_db = int.Parse(eladott_db);
        }
    }
}
